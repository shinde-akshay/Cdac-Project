package in.co.elearning.dto;


public interface DropdownList
{
	public String getKey();

	public String getValue();
}
